<div class="titulo">Conheça-nos</div>

<div class="principallog form-group " >  
    <div style="font-size: 15px; text-align: center" class="seclog ">
        <div style="margin-left: 11%" class="form-row w-75 mt-4">
            <div class="col">
                <p style="font-size: 20px" ><strong>Abigail/Abi (Front end.)</strong></p><br>
                <p>Uma das designers do grupo, nascida em 03 de maio de 2006, Rio do Sul – SC.
                    Contratada pela H. Bremer &amp; Filhos Ltda. Uma excelente desenhista, adoradora de
                    animes e mangas.</p>
                <p>Telefone: (47) 98895-2792</p>
                <p>Instagram: @__iamabii</p>
            </div>
            <div class="col">
                <img style="width: 165px; height: 196px" src="./img/abi.jpg" alt=""/>
            </div>
        </div>
        <div style="margin-left: 11%" class="form-row w-75 mt-5 ">
            <div class="col">
                <p style="font-size: 20px" ><strong>Carlos/Da Muleta (Front end.)</strong></p><br>
                <p>Um dos designers do grupo, nascido em 27 de maio de 2003, Agrolândia –SC.
                    Contratado pela Metalbo. Gosta de jogos e é um grande atleta, ama correr.</p>
                <p>Telefone: (47) 99624-7631</p>
                <p>Instagram: @carlose_freitas</p>
            </div>
            <div class="col">
                <img style="width: 165px; height: 196px" src="./img/carlos.jpg" alt=""/>
            </div>
        </div>
        <div style="margin-left: 11%" class="form-row w-75 mt-5 ">
            <div class="col">
                <p style="font-size: 20px" ><strong>Guilherme/Careca (Back end.)</strong></p><br>
                <p>Um dos programadores do grupo, nascido em 03 de dezembro de 2004, Blumenau – SC.
                    Contratado pela Sibratec. Adora games, animes e mangas.</p>
                <p>Telefone: (47) 99273-3532</p>
                <p>Instagram: @guilherme_senes</p>
            </div>
            <div class="col">
                <img style="width: 165px; height: 196px" src="./img/senes.png" alt=""/>
            </div>
        </div>
        <div style="margin-left: 11%" class="form-row w-75 mt-5 ">
            <div class="col">
                <p style="font-size: 20px" ><strong>Jenifer/Jeni (Front end.)</strong></p><br>
                <p>Uma das Designers do grupo, nascida em 04 de maio de 2004, Rio do Sul – SC
                    Contratada pela Magazord. Adoradora de filmes e séries, gosta de jogos.</p>
                <p>Telefone: (47) 98814-8919</p>
                <p>Instagram: @jenifercristina_duwe</p>
            </div>
            <div class="col">
                <img style="width: 165px; height: 196px" src="./img/jeni.jpg" alt=""/>
            </div>
        </div>
        <div style="margin-left: 11%" class="form-row w-75 mt-5 ">
            <div class="col">
                <p style="font-size: 20px" ><strong>Otávio/ Otávio (Back end.)</strong></p><br>
                <p>Um dos programadores do grupo, nascido em 21 de março de 2004, Agrolândia – SC.
                    Contratado pela Metalbo. Gosta de programar, anime e jogos.</p>
                <p>Telefone: (47) 98909-4839</p>
                <p>Instagram: @otavio_prada</p>
            </div>
            <div class="col">
                <img style="width: 165px; height: 196px" src="./img/otavio.png" alt=""/>
            </div>
        </div>
        <div class="mt-5">
            <h1>Nosso Mestre Mr.Baumann</h1>
        </div>
        <div style="margin-left: 11%" class="form-row w-75 mt-5 ">
            <div class="col">
                <p style="font-size: 20px" ><strong>Daniel Baumann</strong></p><br>
                <p>Graduado em Ciências da Computação na FURB, atua como professor na área de
                    informática há mais de 12 anos. Vulgo o melhor professor do mundo S2</p>
            </div>
            <div class="col">
                <img style="width: 165px; height: 196px" src="./img/daniel.jpg" alt=""/>
            </div>
        </div>