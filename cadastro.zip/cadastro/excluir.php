<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
<script src="js/bootstrap.bundle.min.js" type="text/javascript"></script>
<?php
include './conecta_banco.php';
$id = $_GET['id'];
$sql = "DELETE FROM pessoa WHERE id=$id";
    if ($conn->query($sql) === true) {
            echo "Pessoa Eliminada com sucesso";
        } else {
            echo "Erro: " . $conn->error;
        }
        $conn->close();
?>
<br/>
<a class="btn btn-outline-dark btn-lg" href="lista_visitantes.php">Voltar</a>
    