<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Project/PHP/PHPProject.php to edit this template
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <script src="js/bootstrap.bundle.min.js" type="text/javascript"></script>
    </head>
    <body>
        <?php
        //Recebe dados do formulário
        $id = $_POST['id'];
        $nome = $_POST['nome'];
        $sobrenome = $_POST['sobrenome'];
        $email = $_POST['email'];

        include './conecta_banco.php';
        //Insere um registro
        $sql = "UPDATE pessoa SET nome='$nome',sobrenome='$sobrenome',email='$email',registro=current_timestamp() WHERE id=$id";
        if ($conn->query($sql) === TRUE) {
            echo "Pessoa atualizada com sucesso";
        } else {
            echo "Erro:" . $conn->error;
        }
        $conn->close();
        ?>
        </br>
        </br>
        <a class="btn btn-outline-dark btn-lg" href="index.php">Adicionar nova pessoa</a>
        </br>
        </br>
        <a class="btn btn-outline-dark btn-lg" href="lista_visitantes.php">Mostrar Pessoas</a>
    </body>
</html>