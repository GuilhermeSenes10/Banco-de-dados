<html>
    <head>
        <meta charset="UTF-8">
        <title>CADASTRO</title>
        <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <script src="js/bootstrap.bundle.min.js" type="text/javascript"></script>
    </head>
    <body>
        <form action="cadastrar.php" method="post">
            <label>Nome:</label>
            <input type="text" name="nome"/>
            </br>
            </br>
            <label>Sobrenome:</label>
            <input type="text" name="sobrenome"/>
            </br>
            </br>
            <label>Email:</label>
            <input type="email" name="email"/>
            </br>
            </br>
            <button class="btn btn-outline-dark btn-lg" type="submit">Cadastrar</button>
        </form>
        <a class="btn btn-outline-dark btn-lg" href="lista_visitantes.php">Listar Pessoas</a>
    </body>
</html>
