<?php

//Elementos do banco de dados
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "visitantes";
//Criando conexão
$conn = new mysqli($servername, $username, $password, $dbname);
//Checagem de conexão
if ($conn->connect_error) {
    die("Sinto muito a conexão falhou: " . $conn->connect_error);
}
