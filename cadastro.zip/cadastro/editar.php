<!DOCTYPE html>
<?php
include './conecta_banco.php';
$id = $_GET['id'];
$sql = "SELECT nome,sobrenome,email FROM pessoa WHERE id=$id";
$resultado = $conn->query($sql);
if ($resultado->num_rows > 0) {
     while ($row = $resultado->fetch_assoc()) {
         $nome = $row['nome'];
         $sobrenome = $row['sobrenome'];
         $email = $row['email'];
     }
}
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <script src="js/bootstrap.bundle.min.js" type="text/javascript"></script>
    </head>
    <body>
        <form action="update.php" method="post">
            <input type="hidden" name="id" value="<?php echo $id?>">
            <label>Nome:</label>
            <input type="text" name="nome" value="<?php echo $nome?>"/>
           
            <label>Sobrenome:</label>
            <input type="text" name="sobrenome" value="<?php echo $sobrenome?>"/>
           
            <label>Email:</label>
            <input type="email" name="email" value="<?php echo $email?>"/>
            </br>
            </br>
            <button  class="btn btn-outline-dark btn-lg"type="submit">Atualizar</button>
        </form>
        </br>
        <a class="btn btn-outline-dark btn-lg" href="lista_visitantes.php">Listar Pessoas</a>
    </body>
</html>
