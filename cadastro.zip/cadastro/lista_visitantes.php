<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>

<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
<script src="js/bootstrap.bundle.min.js" type="text/javascript"></script>
<?php

include './conecta_banco.php';
$sql = "SELECT id,nome,sobrenome,email,DATE_FORMAT(registro,'%d/%m%/%Y %H:%i:%s') FROM pessoa";
$resultado = $conn->query($sql);
if ($resultado->num_rows > 0) {
    //Apresenta cada registro
    echo "<table>";
    echo "<tr>";
    echo "<td>ID</td>";
    echo "<td>Nome</td>";
    echo "<td>Sobrenome</td>";
    echo "<td>Email</td>";
    echo "<td>Registro</td>";
    echo "<td>Opções</td>";
    echo "<tr>";
    while ($row = $resultado->fetch_assoc()) {
        echo "<tr>";
        echo "<td>".$row["id"]."</td>";
        echo "<td>".$row["nome"]."</td>";
        echo "<td>".$row["sobrenome"]."</td>";
        echo "<td>".$row["email"]."</td>";
        echo "<td>" . $row["DATE_FORMAT(registro,'%d/%m%/%Y %H:%i:%s')"] . "</td>";
        echo "<td><a href=editar.php?id=".$row["id"]."><img alt=editar src=img/edit.png></a><a href=excluir.php?id=".$row["id"]."><img alt=apagar src=img/del.png></a></td>";
        echo '</tr>';
    }
    echo "</table>";
}
?>
</br>
<a class="btn btn-outline-dark btn-lg" href="index.php">Voltar</a>
